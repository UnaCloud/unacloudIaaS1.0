/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package administration;

import javax.faces.model.SelectItem;

/**
 *
 * @author Clouder
 */
public class Atributos {
    private String name,value,valores[];

    public Atributos(String name, String value, String ... valores) {
        this.name = name;
        this.value = value;
        this.valores = valores;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public SelectItem[] getValores() {
        SelectItem[] r = new SelectItem[valores.length];
        for(int e=0;e<r.length;e++)r[e]=new SelectItem(valores[e],valores[e]);
        return r;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }



}
