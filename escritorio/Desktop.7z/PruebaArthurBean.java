/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package administration;


/**
 *
 * @author Clouder
 */
public class PruebaArthurBean {

    Program[] programas;

    /** Creates a new instance of PruebaArthurBean */
    public PruebaArthurBean() {
        programas=new Program[3];
        programas[0]=new Program("p1",new Atributos("prime a",null,"hola1","hola2","hola3"),new Atributos("bla a",null,"hola5","hola6","hola7"));
        programas[1]=new Program("p2",new Atributos("prime p1",null,"holasfa1","holasfa2","holsafa3"),new Atributos("bla a2",null,"hosdgla5","holsda6","holsdga7"));
        programas[2]=new Program("p3",new Atributos("prime p2",null,"asfaf1","dfg2","hjgh"),new Atributos("at2",null,"hsdgsdg","sdgsdga6","hsdgsa7"));
    }

    public Program[] getProgramas() {
        return programas;
    }

    public void setProgramas(Program[] programas) {
        this.programas = programas;
    }

    

}
