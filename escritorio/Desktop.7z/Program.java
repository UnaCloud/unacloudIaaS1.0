/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package administration;

/**
 *
 * @author Clouder
 */
public class Program {

    String nombre;

    Atributos[] lista;

    public Program(String n,Atributos ... temp) {
        nombre=n;
        lista=temp;
    }

    public Atributos[] getLista() {
        return lista;
    }

    public void setLista(Atributos[] lista) {
        this.lista = lista;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    



}
